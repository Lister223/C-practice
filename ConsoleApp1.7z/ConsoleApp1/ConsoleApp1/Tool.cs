using System;

namespace ConsoleApp1
{
    static class Tool
    {
        public static void SayHi()
        {
            Console.WriteLine("Hello!");
        }
    }
}